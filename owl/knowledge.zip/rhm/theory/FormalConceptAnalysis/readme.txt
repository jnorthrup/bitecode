# 3:00 am 9/26/97

The examples in the KEHOME/fca directory are drawn from
published papers in the area of "Formal Concept Analysis".
The page numbers refer to

	Dickson Lukose, Harry Delugach, Mary Keeler,
	Leroy Searle, John Sowa (Eds.),
	"Conceptual Structures: Fulfilling Peirce's Dream",
	Fifth International Conference on Conceptual Structures, ICCS'97,
	Seattle, Washington, USA, August 3-8, 1997 Proceedings,
	Lecture Notes in Artificial Intelligence 1257,
	Springer-Verlag, 1997.
	ISBN 3-540-63308-1
