# 2:30 pm 10/31/97

The files in the KEHOME/context directory
include a number of examples from

Context in Knowledge Representation and Natural Language
AAAI 1997 Fall Symposium, MIT, November 8-10
